import os
os.chdir('./')
os.system('http-server -o -c-1')
