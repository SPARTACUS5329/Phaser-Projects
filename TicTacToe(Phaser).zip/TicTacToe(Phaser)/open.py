import os
os.chdir('./')
if os.name == 'posix':
    os.system('http-server -o -c-1')
elif os.name == 'nt':
    os.system('python3 -m http.server')
