class TicTacToe extends Phaser.Scene {
    constructor(name){
        super({name})
    }

    preload(){

    }

    create(){
        gameState.rect1 = this.add.rectangle(100,100,200,200,0x123123);
        gameState.rect1.setInteractive();

    }

    update(){
        gameState.rect1.on('pointerup',function(pointer){
            console.log("Pointer is up")
        },this)
    }
}

const gameState = {};